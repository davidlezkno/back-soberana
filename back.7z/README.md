# Templra Back

The application offers an intuitive interface for authentication and user management.

## Prerequisites

Make sure you have the following prerequisites installed before running the application:

- Node.js (version 18 or higher)
- npm (version 8 or higher)
- PostgreSQL (version 15 or higher)

## Configuration

Follow these steps to configure and run the application:

1. Clone this repository:

   ```bash
   git clone <repository-url>
   ```

2. Navigate to the project directory:

   ```bash
   cd template-back
   ```

3. Install the dependencies:

   ```bash
   npm install
   ```

4. Create an .env file in the root directory of your project with the following configuration:

   ```bash
   PORT=3000

   DB_HOST=localhost
   DB_PORT=5432
   DB_USERNAME=postgres
   DB_PASSWORD=postgres
   DB_DATABASE=templra_db
   DB_SCHEMA=public

   JWT_SECRET=your-secret-key-here
   JWT_EXPIRES_IN=24h
   PASSWORD_HASH_SALT=10

   SENDGRID_API_KEY=your-sendgrid-api-key
   SENDGRID_FROM=noreply@example.com

   MAILER_URL=http://localhost:3000
   MAILER_API_KEY=your-mailer-api-key

   CAPTCHA_KEY=your-recaptcha-secret-key

   DOC_ENABLED=true
   TZ=UTC
   ```

5. Run project:

   ```bash
   npm run start:dev
   ```

6. Application, Docs:

   ```bash
     LOG 🚀 Application ⇢ http://localhost:3000/api
     LOG 📖 Swagger ⇢ http://localhost:3000/docs
   ```

## Git Flow

This project follows the Git flow branching model for development and collaboration. The main branches used are:

- master: Represents the production-ready code.
- develop: Serves as the main branch for ongoing development.
- feature/<feature-name>: Used for developing new features.
- bugfix/<bugfix-name>: Used for fixing bugs.
- hotfix/<hotfix-name>: Used for critical fixes in production.
- release/<release-version>: Marks a release point for a specific version.

## Commits:

```bash
     <type>: `[JIRA-123] Describes the type of the commit. Some common types include:
     feat: A new feature
     fix: A bug fix
     docs: Documentation changes
     style: Code style changes (formatting, indentation, etc.)
     refactor: Code refactoring or restructuring
     test: Adding or modifying tests
     chore: Maintenance tasks, build system updates, etc.
     <subject>: A concise description of the commit. Use imperative verbs and keep it under 50 characters.
     <body>: A detailed explanation of the changes. Include relevant information, context, and any additional details about the commit. It can be multiple lines.
     <footer>: Additional information related to the commit, such as references to issue trackers or related pull requests.
```

## Docker Compose

If you prefer to run the application using Docker Compose, follow these steps:

1. Make sure you have Docker and Docker Compose installed on your machine.

2. Run the following command to start the application using Docker Compose:

   ```bash
   docker-compose up
   ```

3. If you want to remove the containers and associated volumes, run the following command:

   ```bash
   docker-compose down -v
   ```

## Docker

To build and run the application using Docker:

1. Build the Docker image:

   ```bash
   docker build -t templra-back .
   ```

2. Run the container:

   ```bash
   docker run -p 3000:3000 templra-back
   ```

