/**
 * Response Utility
 * @description this method standardizes the answers
 * @param  {any} items
 */
export default function ResponseUtility(items: any) {
  return {
    items,
  };
}

