// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { InventoryLine } from '../entities/inventory-line.entity';

@Injectable()
export class InventoryLineRepository extends Repository<InventoryLine> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(InventoryLine, dataSource.createEntityManager());
  }
}

