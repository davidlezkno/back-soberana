// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { InventoryLine } from './entities/inventory-line.entity';

// Import services
import { InventoryLineService } from './inventory-line.service';

// Import controllers
import { InventoryLineController } from './inventory-line.controller';

// Import repositories
import { InventoryLineRepository } from './repositories/inventory-line.repository';

@Module({
  imports: [TypeOrmModule.forFeature([InventoryLine])],
  controllers: [InventoryLineController],
  providers: [InventoryLineService, InventoryLineRepository],
  exports: [InventoryLineService, InventoryLineRepository],
})
export class InventoryLineModule {}

