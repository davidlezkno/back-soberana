// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { InventoryCount } from '../entities/inventory-count.entity';

@Injectable()
export class InventoryCountRepository extends Repository<InventoryCount> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(InventoryCount, dataSource.createEntityManager());
  }
}

