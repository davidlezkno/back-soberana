// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { InventoryCount } from './entities/inventory-count.entity';

// Import services
import { InventoryCountService } from './inventory-count.service';

// Import controllers
import { InventoryCountController } from './inventory-count.controller';

// Import repositories
import { InventoryCountRepository } from './repositories/inventory-count.repository';

@Module({
  imports: [TypeOrmModule.forFeature([InventoryCount])],
  controllers: [InventoryCountController],
  providers: [InventoryCountService, InventoryCountRepository],
  exports: [InventoryCountService, InventoryCountRepository],
})
export class InventoryCountModule {}

