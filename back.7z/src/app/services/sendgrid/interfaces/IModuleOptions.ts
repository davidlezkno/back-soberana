export default interface ISendgridModuleOption {
  apiKey: string;
  from: string;
}

