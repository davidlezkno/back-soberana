export default {
  error: {
    http_code: 500,
    title: '[RECORD] ERROR EMAIL',
    message: 'Error email',
  },
};

