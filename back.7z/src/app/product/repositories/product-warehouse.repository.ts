// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { ProductWarehouse } from '../entities/product-warehouse.entity';

@Injectable()
export class ProductWarehouseRepository extends Repository<ProductWarehouse> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(ProductWarehouse, dataSource.createEntityManager());
  }
}

