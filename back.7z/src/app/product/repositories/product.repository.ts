// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { Product } from '../entities/product.entity';

@Injectable()
export class ProductRepository extends Repository<Product> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(Product, dataSource.createEntityManager());
  }
}

