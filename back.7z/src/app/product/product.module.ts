// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { Product } from './entities/product.entity';
import { ProductWarehouse } from './entities/product-warehouse.entity';
import { User } from '../users/entities/user.entity';

// Import services
import { ProductService } from './product.service';

// Import controllers
import { ProductController } from './product.controller';

// Import repositories
import { ProductRepository } from './repositories/product.repository';
import { ProductWarehouseRepository } from './repositories/product-warehouse.repository';
import { UserRepository } from '../users/repositories/user.repository';

@Module({
  imports: [TypeOrmModule.forFeature([Product, ProductWarehouse, User])],
  controllers: [ProductController],
  providers: [ProductService, ProductRepository, ProductWarehouseRepository, UserRepository],
  exports: [ProductService, ProductRepository],
})
export class ProductModule {}

