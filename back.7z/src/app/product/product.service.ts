import { Injectable } from '@nestjs/common';

import {
  DeepPartial,
  FindManyOptions,
  FindOptionsWhere,
  ILike,
  Raw,
} from 'typeorm';

import { ProductRepository } from './repositories/product.repository';
import { ProductWarehouseRepository } from './repositories/product-warehouse.repository';
import { UserRepository } from '../users/repositories/user.repository';

import { Product } from './entities/product.entity';
import { ProductWarehouse } from './entities/product-warehouse.entity';
import { Warehouse } from '../warehouse/entities/warehouse.entity';

import { CreateProductDto } from './dto/create-product.dto';
import { SelectProductDto } from './dto/select-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';

import PermissionUtility from 'src/utils/permission.utility';
import { Exception } from '../../utils/exception.utility';
import { exceptions } from './constants';
import { User } from '../users/entities/user.entity';

@Injectable()
export class ProductService {
  constructor(
    private readonly productRepository: ProductRepository,
    private readonly productWarehouseRepository: ProductWarehouseRepository,
    private readonly userRepository: UserRepository
  ) {}

  /**
   * Create
   * @description Create a new record
   * @param  {CreateProductDto} createProductDto
   * @param  {User} user
   */
  async create(createProductDto: CreateProductDto, user: User) {
    const data: DeepPartial<Product> = {
      code: createProductDto.code.trim(),
      name: createProductDto.name.trim(),
      description: createProductDto.description.trim(),
      packagingUnit: createProductDto.packagingUnit.trim(),
      conversionFactor: createProductDto.conversionFactor,
      price: createProductDto.price,
      createdBy: user,
    };

    const result = await this.productRepository.save(data)
      .catch((error) => {
        if (error.code === '23505')
          throw Exception(
            error.detail.includes('code')
              ? exceptions.duplicated
              : exceptions.duplicatedCode
          );

        throw Exception(exceptions.error_save, [], error);
      });

    if (createProductDto.quantities && createProductDto.quantities.length > 0) {
      const productWarehouseData: DeepPartial<ProductWarehouse>[] = createProductDto.quantities.map(
        (item) => ({
          product: { id: result.id } as Product,
          warehouse: { id: item.warehouse_id } as Warehouse,
          quantity: item.quantity,
        })
      );

      await this.productWarehouseRepository
        .save(productWarehouseData)
        .catch((error) => {
          throw Exception(exceptions.error_save, [], error);
        });
    }

    return result;
  }

  /**
   * FindAll
   * @description Get all records
   * @param  {SelectProductDto} query
   * @param  {User} user
   */
  async findAll(
    {
      code,
      name,
      description,
      packagingUnit,
      active,
      search,
      created_at,
      warehouse,
      limit = 20,
      page = 0,
    }: SelectProductDto,
    user: User
  ) {
    const permission = PermissionUtility(user);

    if (permission.user.id.length === 0) return [];

    const andConditions: FindOptionsWhere<Product> = {};
    const orConditions: FindOptionsWhere<Product>[] = [];

    if (search) {
      orConditions.push(
        { code: ILike(`%${search}%`) },
        { name: ILike(`%${search}%`) },
        { description: ILike(`%${search}%`) }
      );
    }

    if (code) andConditions.code = code;
    if (name) andConditions.name = ILike(`%${name}%`);
    if (description) andConditions.description = ILike(`%${description}%`);
    if (packagingUnit) andConditions.packagingUnit = ILike(`%${packagingUnit}%`);
    if (active !== undefined) andConditions.active = active;

    if (created_at) {
      const [year, month] = created_at.split('T')[0].split('-');
      let day = created_at.split('T')[0].split('-')[2];
      const [hour] = created_at.split('T')[1].replace('Z', '').split(':');

      if (parseInt(hour, 10) + 5 >= 24) {
        day = String(parseInt(day, 10) + 1).padStart(2, '0');
      }

      const adjustedStart = `${year}-${month}-${day} 00:00:00`;
      const adjustedEnd = `${year}-${month}-${day} 23:59:59`;

      andConditions.created_at = Raw(
        (alias) =>
          `DATE(${alias} - INTERVAL '5 hours') BETWEEN '${adjustedStart}'::TIMESTAMP 
            AND '${adjustedEnd}'::TIMESTAMP`
      );
    }

    const where =
      orConditions.length > 0
        ? { ...andConditions, OR: orConditions }
        : andConditions;

    if (warehouse) {
      const warehouseId = warehouse;
      const queryBuilder = this.productRepository
        .createQueryBuilder('product')
        .leftJoinAndSelect('product.productWarehouses', 'productWarehouse')
        .leftJoinAndSelect('productWarehouse.warehouse', 'warehouse')
        .innerJoin('product.productWarehouses', 'pw', 'pw.warehouse_id = :warehouseId', { warehouseId })
        .where('product.id = pw.product_id')
        .skip(limit * page)
        .take(limit)
        .orderBy('product.created_at', 'DESC');

      const result = await queryBuilder.getMany().catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

      const countQueryBuilder = this.productRepository
        .createQueryBuilder('product')
        .innerJoin('product.productWarehouses', 'pw', 'pw.warehouse_id = :warehouseId', { warehouseId })
        .where('product.id = pw.product_id');

      const length = await countQueryBuilder.getCount().catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

      return { items: result, length };
    }

    const init_search: FindManyOptions<Product> = {
      where,
      relations: ['productWarehouses', 'productWarehouses.warehouse'],
      skip: limit * page,
      take: limit,
      order: { created_at: 'DESC' },
    };

    if (
      !init_search.where ||
      (Array.isArray(init_search.where) && init_search.where.length === 0)
    )
      delete init_search.where;

    const result = await this.productRepository
      .find(init_search)
      .catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    const length = await this.productRepository.count({ where });

    return { items: result, length };
  }

  /**
   * FindByUserId
   * @description Get all products from all warehouses assigned to a user
   * @param  {string} userId
   */
  async findByUserId(userId: string) {
    const user = await this.userRepository
      .findOne({
        where: { id: userId },
        relations: ['warehouses'],
      })
      .catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    if (!user || !user.warehouses || user.warehouses.length === 0) {
      return { items: [], length: 0 };
    }

    const warehouseIds = user.warehouses.map((warehouse) => warehouse.id);

    const queryBuilder = this.productRepository
      .createQueryBuilder('product')
      .leftJoinAndSelect('product.productWarehouses', 'productWarehouse')
      .leftJoinAndSelect('productWarehouse.warehouse', 'warehouse')
      .innerJoin('product.productWarehouses', 'pw', 'pw.warehouse_id IN (:...warehouseIds)', { warehouseIds })
      .where('product.id = pw.product_id')
      .orderBy('product.created_at', 'DESC');

    // Get results
    const result = await queryBuilder.getMany().catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    const uniqueProducts = result.filter(
      (product, index, self) => index === self.findIndex((p) => p.id === product.id)
    );

    return { items: uniqueProducts, length: uniqueProducts.length };
  }

  /**
   * FindOne
   * @description Get one record
   * @param  {string} id
   */
  async findOne(id: string, isRequired = true) {
    const result = await this.productRepository
      .findOne({
        where: { id: id },
        relations: ['productWarehouses', 'productWarehouses.warehouse'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result && isRequired) throw Exception(exceptions.not_found, []);

    // Return result
    return result;
  }

  /**
   * FindOneByCode
   * @description Get one record by code
   * @param  {string} code
   */
  async findOneByCode(code: string, isRequired = true) {
    const result = await this.productRepository
      .findOne({
        where: { code: code },
        relations: ['productWarehouses', 'productWarehouses.warehouse'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result && isRequired) throw Exception(exceptions.not_found, []);

    // Return result
    return result;
  }

  /**
   * Update
   * @description Update one record
   * @param  {string} id
   * @param  {UpdateProductDto} updateProductDto
   * @param  {User} user
   */
  async update(id: string, updateProductDto: UpdateProductDto, user: User) {
    const find = await this.productRepository
      .findOneBy({ id: id })
      .catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    if (!find) throw Exception(exceptions.not_found, []);

    const data: DeepPartial<Product> = {
      id: find.id,
    };

    if (updateProductDto.code) data.code = updateProductDto.code.trim();
    if (updateProductDto.name) data.name = updateProductDto.name.trim();
    if (updateProductDto.description) data.description = updateProductDto.description.trim();
    if (updateProductDto.packagingUnit) data.packagingUnit = updateProductDto.packagingUnit.trim();
    if (updateProductDto.conversionFactor !== undefined) data.conversionFactor = updateProductDto.conversionFactor;
    if (updateProductDto.price !== undefined) data.price = updateProductDto.price;
    data.updatedBy = user;

    const result = await this.productRepository.save(data).catch((error) => {
      if (error.code === '23505')
        throw Exception(
          error.detail.includes('code')
            ? exceptions.duplicated
            : exceptions.duplicatedCode
        );

      throw Exception(exceptions.error_update, [], error);
      });

    if (updateProductDto.quantities !== undefined) {
      const existingProductWarehouses = await this.productWarehouseRepository
        .find({
          where: { product: { id: result.id } as Product },
          relations: ['warehouse'],
        })
        .catch((error) => {
          throw Exception(exceptions.error_find, [], error);
        });

      if (updateProductDto.quantities.length > 0) {
        for (const item of updateProductDto.quantities) {
          const existing = existingProductWarehouses.find(
            (pw) => pw.warehouse.id === item.warehouse_id
          );

          if (existing) {
            existing.quantity = item.quantity;
            await this.productWarehouseRepository.save(existing).catch((error) => {
                throw Exception(exceptions.error_update, [], error);
              });
          } else {
            const newProductWarehouse: DeepPartial<ProductWarehouse> = {
              product: { id: result.id } as Product,
              warehouse: { id: item.warehouse_id } as Warehouse,
              quantity: item.quantity,
            };
            await this.productWarehouseRepository.save(newProductWarehouse).catch((error) => {
              throw Exception(exceptions.error_save, [], error);
            });
          }
        }

        const warehouseIdsInQuantities = updateProductDto.quantities.map(
            (item) => item.warehouse_id
        );

        const recordsToDelete = existingProductWarehouses.filter(
            (pw) => !warehouseIdsInQuantities.includes(pw.warehouse.id)
        );

        if (recordsToDelete.length > 0) {
          await this.productWarehouseRepository
            .remove(recordsToDelete)
            .catch((error) => {
              throw Exception(exceptions.error_delete, [], error);
            });
        }
      } else {
        if (existingProductWarehouses.length > 0) {
          await this.productWarehouseRepository
            .remove(existingProductWarehouses)
            .catch((error) => {
              throw Exception(exceptions.error_delete, [], error);
            });
        }
      }
    }
    
    const updated = await this.productRepository
      .findOne({
        where: { id: result.id },
      })
      .catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    return updated || result;
  }

  /**
   * Remove
   * @description Remove one record
   * @param  {string} id
   */
  async remove(id: string) {
    const find = await this.productRepository
      .findOneBy({ id: id })
      .catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    if (!find) throw Exception(exceptions.not_found, []);

    const result = await this.productRepository
      .save({ ...find, active: false })
      .catch((error) => {
        throw Exception(exceptions.error_delete, [], error);
      });

    // Return result
    return result;
  }

  /**
   * Reactivate
   * @description Reactivate one record
   * @param  {string} id
   */
  async reactivate(id: string) {
    const find = await this.productRepository
      .findOneBy({ id: id })
      .catch((error) => {
        throw Exception(exceptions.error_find, [], error);
      });

    if (!find) throw Exception(exceptions.not_found, []);

    const result = await this.productRepository
      .save({ ...find, active: true })
      .catch((error) => {
        throw Exception(exceptions.error_delete, [], error);
      });

    return result;
  }
}

