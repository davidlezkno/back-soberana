export default {
  error_save: {
    http_code: 500,
    title: '[LOGIN_AUDIT] ERROR_SAVE',
    message: 'Error to save',
  },
};

