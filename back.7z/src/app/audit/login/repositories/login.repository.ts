// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { LoginAudit } from '../entities/login.entity';

@Injectable()
export class LoginAuditRepository extends Repository<LoginAudit> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(LoginAudit, dataSource.createEntityManager());
  }
}

