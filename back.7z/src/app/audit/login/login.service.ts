// Import core
import { Injectable } from '@nestjs/common';

// Import repositories
import { LoginAuditRepository } from './repositories/login.repository';

// Import dto
import { CreateLoginAuditDto } from './dto/create-login.dto';

// Imports
import { exceptions } from './constants';
import { Exception } from '../../../utils/exception.utility';

@Injectable()
export class LoginAuditService {
  // Inject services
  constructor(private readonly loginAuditsRepository: LoginAuditRepository) {}

  /**
   * Create
   * @description Create a new record
   * @param  {CreateLoginAuditDto} createLoginAuditsDto
   */
  async create(createLoginAuditsDto: CreateLoginAuditDto) {
    // Save record
    const result = await this.loginAuditsRepository
      .save({
        username: createLoginAuditsDto.username.trim(),
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_save, [], error);
      });

    // Return result
    return result;
  }
}

