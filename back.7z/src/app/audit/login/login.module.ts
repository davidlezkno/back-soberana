// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { LoginAudit } from './entities/login.entity';

// Import services
import { LoginAuditService } from './login.service';

// Import modules
import { ConfigModule } from '@nestjs/config';

// Import repositories
import { LoginAuditRepository } from './repositories/login.repository';

@Module({
  imports: [TypeOrmModule.forFeature([LoginAudit]), ConfigModule],
  providers: [LoginAuditService, LoginAuditRepository],
  exports: [LoginAuditService],
})
export class LoginAuditModule {}

