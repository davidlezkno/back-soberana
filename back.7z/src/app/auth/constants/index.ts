export { default as exceptions } from './exceptions';
export const URL_CAPTCHA =
  'https://www.google.com/recaptcha/api/siteverify?secret=';

