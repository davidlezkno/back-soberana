// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import {
  DeepPartial,
  FindManyOptions,
  FindOptionsWhere,
  ILike,
  Raw,
  In,
} from 'typeorm';

// Import repositories
import { UserRepository } from './repositories/user.repository';
import { WarehouseRepository } from '../warehouse/repositories/warehouse.repository';

// Import entity
import { User } from './entities/user.entity';
import { Warehouse } from '../warehouse/entities/warehouse.entity';

// Import services
import { ConfigService } from '@nestjs/config';

// Import dto
import { CreateUserDto } from './dto/create-user.dto';
import { SelectByRolUserDto, SelectUserDto } from './dto/select-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

// Imports
import { hash, compare } from 'bcrypt';
import PermissionUtility from 'src/utils/permission.utility';
import { Exception } from '../../utils/exception.utility';
import { UserTypeEnum, exceptions } from './constants';

@Injectable()
export class UsersService {
  // Inject services
  constructor(
    private readonly userRepository: UserRepository,
    private readonly configService: ConfigService,
    private readonly warehouseRepository: WarehouseRepository
  ) {}

  /**
   * Create
   * @description Create a new record
   * @param  {CreateUserDto} createUserDto
   */
  async create(createUserDto: CreateUserDto) {
    // Check if the password is valid
    if (createUserDto.password !== createUserDto.password_retry)
      throw Exception(exceptions.bad_request);

    // Create the password hash
    const password_hash = await hash(
      createUserDto.password,
      parseInt(this.configService.get<string>('PASSWORD_HASH_SALT'))
    );

    // Save record
    const result = await this.userRepository
      .save({
        password: password_hash,
        name: createUserDto.name.trim(),
        document: createUserDto.document.trim(),
        surname: createUserDto.surname.trim(),
        username: createUserDto.username.toLowerCase().trim(),
        type: Object.values(UserTypeEnum).find((v) => v === createUserDto.type)
          ? createUserDto.type
          : UserTypeEnum.User,
      })
      .catch((error) => {
        // Catch error in database transaction duplicated
        if (error.code === '23505')
          throw Exception(
            error.detail.includes('username')
              ? exceptions.duplicated
              : exceptions.duplicatedCode
          );

        // Catch error in database transaction
        throw Exception(exceptions.error_save, [], error);
      });

    // If warehouses are provided, relate them to the user
    if (createUserDto.warehouses && createUserDto.warehouses.length > 0) {
      // Find warehouses by IDs
      const warehouses = await this.warehouseRepository
        .findBy({ id: In(createUserDto.warehouses) })
        .catch((error) => {
          // Catch error in database transaction
          throw Exception(exceptions.error_find, [], error);
        });

      // Relate warehouses to user
      result.warehouses = warehouses;
      await this.userRepository.save(result);
    }

    // Load warehouses relation
    const userWithWarehouses = await this.userRepository.findOne({
      where: { id: result.id },
      relations: ['warehouses'],
    });

    // Return result with warehouses
    return {
      ...result,
      warehouses: userWithWarehouses?.warehouses || [],
    };
  }

  /**
   * FindAll
   * @description Get all records
   * @param  {SelectUserDto} query
   * @param  {User} user
   */
  async findAll(
    {
      document,
      name,
      surname,
      username,
      active,
      search,
      created_at,
      limit = 20,
      page = 0,
    }: SelectUserDto,
    user: User
  ) {
    const permission = PermissionUtility(user);

    if (permission.user.id.length === 0) return [];

    const andConditions: FindOptionsWhere<User> = {};
    const orConditions: FindOptionsWhere<User>[] = [];

    // If search exists
    if (search) {
      orConditions.push(
        { document: ILike(`%${search}%`) },
        { name: ILike(`%${search}%`) },
        { surname: ILike(`%${search}%`) },
        { username: ILike(`%${search}%`) }
      );
    }

    if (document) andConditions.document = document;
    if (name) andConditions.name = ILike(`%${name}%`);
    if (surname) andConditions.surname = ILike(`%${surname}%`);
    if (username) andConditions.username = ILike(`%${username}%`);
    if (active !== undefined) andConditions.active = active;

    if (created_at) {
      const [year, month] = created_at.split('T')[0].split('-');
      let day = created_at.split('T')[0].split('-')[2];
      const [hour] = created_at.split('T')[1].replace('Z', '').split(':');

      if (parseInt(hour, 10) + 5 >= 24) {
        day = String(parseInt(day, 10) + 1).padStart(2, '0');
      }

      const adjustedStart = `${year}-${month}-${day} 00:00:00`;
      const adjustedEnd = `${year}-${month}-${day} 23:59:59`;

      andConditions.created_at = Raw(
        (alias) =>
          `DATE(${alias} - INTERVAL '5 hours') BETWEEN '${adjustedStart}'::TIMESTAMP 
            AND '${adjustedEnd}'::TIMESTAMP`
      );
    }

    const where =
      orConditions.length > 0
        ? { ...andConditions, OR: orConditions }
        : andConditions;

    // Initialize search
    const init_search: FindManyOptions<User> = {
      where,
      relations: ['warehouses'],
      skip: limit * page,
      take: limit,
      order: { created_at: 'DESC' },
    };

    // Clear the where if it is empty
    if (
      !init_search.where ||
      (Array.isArray(init_search.where) && init_search.where.length === 0)
    )
      delete init_search.where;

    // Save record
    const result = await this.userRepository
      .find(init_search)
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // Return result with warehouses (already loaded in relations)
    const length = await this.userRepository.count({ where });

    // Return result
    return { items: result, length };
  }

  /**
   * findAllByRol
   * @description Get all records
   * @param  {SelectByRolUserDto} query
   * @param  {User} user
   */
  async findAllByRol(
    { rol = UserTypeEnum.User, search, limit, page }: SelectByRolUserDto,
    user: User
  ) {
    const permission = PermissionUtility(user);

    if (permission.user.id.length === 0) return [];

    // initialize and
    const _and: any = { active: true };

    // Initialize where
    const where: FindOptionsWhere<User>[] = [];

    if (rol && rol !== 'all') where.push({ type: rol });

    // If search exists
    if (search) {
      where.push({ document: ILike(`%${search}%`) });
      where.push({ name: ILike(`%${search}%`) });
      where.push({ surname: ILike(`%${search}%`) });
      where.push({ username: ILike(`%${search}%`) });
    }

    // Union and in or
    where.forEach((element, index) => {
      where[index] = { ..._and, ...element };
    });

    // If where is empty
    if (where.length === 0 && Object.entries(_and).length > 0) where.push(_and);

    // Initialize search
    const init_search: FindManyOptions<User> = {
      where,
      relations: ['warehouses'],
      order: { created_at: 'DESC' },
    };

    if (limit !== undefined && page !== undefined) {
      init_search.skip = limit * page;
      init_search.take = limit;
    }

    // Clear the where if it is empty
    if (
      !init_search.where ||
      (Array.isArray(init_search.where) && init_search.where.length === 0)
    )
      delete init_search.where;

    // Save record
    const result = await this.userRepository
      .find(init_search)
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // Return result with warehouses (already loaded in relations)
    const length = await this.userRepository.count({ where });

    // Return result
    return { items: result, length };
  }

  /**
   * FindOne
   * @description Get one record
   * @param  {string} id
   */
  async findOne(id: string, isRequired = true) {
    // Find record
    const result = await this.userRepository
      .findOne({
        where: { id: id },
        relations: ['warehouses'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result && isRequired) throw Exception(exceptions.not_found, []);

    // Return result with warehouses (already loaded in relations)
    return result;
  }

  /**
   * FindOne
   * @description Get one record
   * @param  {string} email
   */
  async findOneByEmail(email: string, isRequired = true) {
    // Find record
    const result = await this.userRepository
      .findOne({
        where: { username: email },
        relations: ['warehouses'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result && isRequired) throw Exception(exceptions.not_found, []);

    // Return result with warehouses (already loaded in relations)
    return result;
  }

  /**
   * FindOne
   * @description Get one record
   * @param  {string} email
   * @param  {string} password
   */
  async validatePassword(email: string, password: string) {
    // Save record
    const result = await this.userRepository
      .findOneBy({ username: email })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result) throw Exception(exceptions.not_found, []);

    // If incorrect password
    const valid = await compare(password, result.password);
    if (!valid) throw Exception(exceptions.error_password);

    // Return result
    return true;
  }

  /**
   * FindOneBy
   * @description Get one record
   * @param  {FindOptionsWhere<User>} where
   */
  async findOneBy(where: FindOptionsWhere<User>) {
    // Find record
    const result = await this.userRepository
      .findOne({
        where,
        relations: ['warehouses'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result) throw Exception(exceptions.not_found, []);

    // Return result with warehouses (already loaded in relations)
    return result;
  }

  /**
   * profile
   * @description Get one record
   * @param  {User} user
   */
  async profile(user: User) {
    // Find record
    const result = await this.userRepository
      .find({
        where: {
          id: user.id,
          active: true,
        },
        relations: ['warehouses'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result) throw Exception(exceptions.not_found, []);

    // Return result with warehouses (already loaded in relations)
    return result;
  }

  /**
   * Update
   * @description Update one record
   * @param  {string} id
   * @param  {UpdateUserDto} updateUserDto
   * @param  {User} user
   */
  async update(id: string, updateUserDto: UpdateUserDto, password?: boolean) {
    // Save record
    const find = await this.userRepository
      .findOneBy({ id: id })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!find) throw Exception(exceptions.not_found, []);

    const data: DeepPartial<User> = { ...find };

    if (!password) {
      if (updateUserDto.name) data.name = updateUserDto.name;
      if (updateUserDto.type) data.type = updateUserDto.type;
      if (updateUserDto.document) data.document = updateUserDto.document;
      if (updateUserDto.surname) data.surname = updateUserDto.surname;
      if (updateUserDto.username)
        data.username = updateUserDto.username.toLowerCase().trim();
    }
    data.password_change = updateUserDto.password_change;

    if (Boolean(updateUserDto.password)) {
      if (updateUserDto.password !== updateUserDto.password_retry)
        throw Exception(exceptions.bad_request);

      // Create the password hash
      data.password = await hash(
        updateUserDto.password,
        parseInt(this.configService.get<string>('PASSWORD_HASH_SALT'))
      );
      data.last_password_change = new Date();
    }

    // Save record
    const result = await this.userRepository.save(data).catch((error) => {
      // Catch error in database transaction duplicated
      if (error.code === '23505')
        throw Exception(
          error.detail.includes('username')
            ? exceptions.duplicated
            : exceptions.duplicatedCode
        );

      // Catch error in database transaction
      throw Exception(exceptions.error_update, [], error);
    });

    // If warehouses are provided, update user-warehouse relationships
    if (updateUserDto.warehouses !== undefined) {
      // Get existing warehouses for this user
      const existingUser = await this.userRepository
        .findOne({
          where: { id: result.id },
          relations: ['warehouses'],
        })
        .catch((error) => {
          throw Exception(exceptions.error_find, [], error);
        });

      if (updateUserDto.warehouses.length > 0) {
        // Find warehouses by IDs
        const warehouses = await this.warehouseRepository
          .findBy({ id: In(updateUserDto.warehouses) })
          .catch((error) => {
            throw Exception(exceptions.error_find, [], error);
          });

        // Update warehouses relation
        result.warehouses = warehouses;
        await this.userRepository.save(result);
      } else {
        // If warehouses array is empty, remove all relationships
        result.warehouses = [];
        await this.userRepository.save(result);
      }
    }

    // Load warehouses relation
    const userWithWarehouses = await this.userRepository.findOne({
      where: { id: result.id },
      relations: ['warehouses'],
    });

    // Return result with warehouses
    return {
      ...result,
      warehouses: userWithWarehouses?.warehouses || [],
    };
  }

  /**
   * Remove
   * @description Remove one record
   * @param  {string} id
   */
  async remove(id: string) {
    // Find record
    const find = await this.userRepository
      .findOne({
        where: { id: id },
        relations: ['warehouses'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!find) throw Exception(exceptions.not_found, []);

    // Save record
    const result = await this.userRepository
      .save({ ...find, active: false })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_delete, [], error);
      });

    // Return result with warehouses (already loaded in relations)
    return {
      ...result,
      warehouses: find.warehouses || [],
    };
  }

  /**
   * Reactivate
   * @description Reactivate one record
   * @param  {string} id
   */
  async reactivate(id: string) {
    // Find record
    const find = await this.userRepository
      .findOne({
        where: { id: id },
        relations: ['warehouses'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!find) throw Exception(exceptions.not_found, []);

    // Save record
    const result = await this.userRepository
      .save({ ...find, active: true })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_delete, [], error);
      });

    // Return result with warehouses (already loaded in relations)
    return {
      ...result,
      warehouses: find.warehouses || [],
    };
  }
}

