export enum UserTypeEnum {
  Admin = 'admin',
  User = 'user',
}

export { default as exceptions } from './exceptions';

