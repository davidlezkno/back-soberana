// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { User } from './entities/user.entity';

// Import services
import { UsersService } from './users.service';

// Import controllers
import { UsersController } from './users.controller';

// Import modules
import { ConfigModule } from '@nestjs/config';

// Import repositories
import { UserRepository } from './repositories/user.repository';
import { WarehouseRepository } from '../warehouse/repositories/warehouse.repository';

// Import entities
import { Warehouse } from '../warehouse/entities/warehouse.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User, Warehouse]), ConfigModule],
  controllers: [UsersController],
  providers: [UsersService, UserRepository, WarehouseRepository],
  exports: [UsersService, UserRepository],
})
export class UsersModule {}

