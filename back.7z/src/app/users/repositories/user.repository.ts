// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { User } from '../entities/user.entity';

@Injectable()
export class UserRepository extends Repository<User> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(User, dataSource.createEntityManager());
  }
}

