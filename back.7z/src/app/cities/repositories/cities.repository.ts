// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { Cities } from '../entities/cities.entity';

@Injectable()
export class CitiesRepository extends Repository<Cities> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(Cities, dataSource.createEntityManager());
  }
}

