// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { FindManyOptions, FindOptionsWhere } from 'typeorm';

// Import repositories
import { CitiesRepository } from './repositories/cities.repository';

// Import entity
import { Cities } from './entities/cities.entity';

@Injectable()
export class CitiesService {
  // Inject services
  constructor(private readonly citiesRepository: CitiesRepository) {}

  /**
   * GetAll
   * @description Get all active records
   */
  async getAll() {
    // Initialize search
    const init_search: FindManyOptions<Cities> = {
      where: {
        isActive: true,
      },
      order: { name: 'ASC' },
    };

    // Get all records
    const result = await this.citiesRepository.find(init_search);

    // Return result
    return result;
  }

  /**
   * FindById
   * @description Get one record by id
   * @param  {string} id
   */
  async findById(id: string) {
    // Find record
    const result = await this.citiesRepository.findOne({
      where: {
        id: id,
        isActive: true,
      },
    });

    // Return result
    return result;
  }

  /**
   * FindByDepto
   * @description Get all records by department id
   * @param  {string} departmentId
   */
  async findByDepto(departmentId: string) {
    // Initialize search
    const init_search: FindManyOptions<Cities> = {
      where: {
        department: {
          id: departmentId,
        },
        isActive: true,
      } as FindOptionsWhere<Cities>,
      order: { name: 'ASC' },
    };

    // Get all records
    const result = await this.citiesRepository.find(init_search);

    // Return result
    return result;
  }
}

