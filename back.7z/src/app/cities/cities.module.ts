// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { Cities } from './entities/cities.entity';

// Import services
import { CitiesService } from './cities.service';

// Import controllers
import { CitiesController } from './cities.controller';

// Import repositories
import { CitiesRepository } from './repositories/cities.repository';

@Module({
  imports: [TypeOrmModule.forFeature([Cities])],
  controllers: [CitiesController],
  providers: [CitiesService, CitiesRepository],
  exports: [CitiesService, CitiesRepository],
})
export class CitiesModule {}

