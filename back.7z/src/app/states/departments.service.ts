// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { FindManyOptions, FindOptionsWhere } from 'typeorm';

// Import repositories
import { DepartmentsRepository } from './repositories/departments.repository';

// Import entity
import { Departments } from './entities/departments.entity';

@Injectable()
export class DepartmentsService {
  // Inject services
  constructor(
    private readonly departmentsRepository: DepartmentsRepository
  ) {}
  

  /**
   * GetAll
   * @description Get all active records
   */
  async getAll() {
    // Initialize search
    const init_search: FindManyOptions<Departments> = {
      where: {
        isActive: true,
      },
      order: { name: 'ASC' },
    };

    // Get all records
    const result = await this.departmentsRepository.find(init_search);

    // Return result
    return result;
  }

  /**
   * FindById
   * @description Get one record by id
   * @param  {string} id
   */
  async findById(id: string) {
    // Find record
    const result = await this.departmentsRepository.findOne({
      where: {
        id: id,
        isActive: true,
      },
    });

    // Return result
    return result;
  }

  /**
   * FindByCountry
   * @description Get all records by country id
   * @param  {string} countryId
   */
  async findByCountry(countryId: string) {
    // Initialize search
    const init_search: FindManyOptions<Departments> = {
      where: {
        country: {
          id: countryId,
        },
        isActive: true,
      } as FindOptionsWhere<Departments>,
      order: { name: 'ASC' },
    };

    // Get all records
    const result = await this.departmentsRepository.find(init_search);

    // Return result
    return result;
  }
}

