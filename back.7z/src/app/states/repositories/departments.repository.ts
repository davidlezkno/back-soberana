// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { Departments } from '../entities/departments.entity';

@Injectable()
export class DepartmentsRepository extends Repository<Departments> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(Departments, dataSource.createEntityManager());
  }
}

