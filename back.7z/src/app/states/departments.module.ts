// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities

// Import services
import { DepartmentsService } from './departments.service';

// Import controllers
import { DepartmentsController } from './departments.controller';

// Import repositories
import { DepartmentsRepository } from './repositories/departments.repository';
import { Departments } from './entities/departments.entity';


@Module({
  imports: [TypeOrmModule.forFeature([Departments])],
  controllers: [DepartmentsController],
  providers: [DepartmentsService, DepartmentsRepository],
  exports: [DepartmentsService, DepartmentsRepository],
})
export class DepartmentsModule {}

