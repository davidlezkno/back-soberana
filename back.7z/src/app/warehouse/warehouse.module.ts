// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { Warehouse } from './entities/warehouse.entity';

// Import services
import { WarehouseService } from './warehouse.service';

// Import controllers
import { WarehouseController } from './warehouse.controller';

// Import repositories
import { WarehouseRepository } from './repositories/warehouse.repository';

@Module({
  imports: [TypeOrmModule.forFeature([Warehouse])],
  controllers: [WarehouseController],
  providers: [WarehouseService, WarehouseRepository],
  exports: [WarehouseService, WarehouseRepository],
})
export class WarehouseModule {}

