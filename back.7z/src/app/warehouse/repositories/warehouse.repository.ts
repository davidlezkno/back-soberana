// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { DataSource, Repository } from 'typeorm';

// Import entities
import { Warehouse } from '../entities/warehouse.entity';

@Injectable()
export class WarehouseRepository extends Repository<Warehouse> {
  // Inject the data source
  constructor(protected dataSource: DataSource) {
    // Call the parent constructor
    super(Warehouse, dataSource.createEntityManager());
  }
}

