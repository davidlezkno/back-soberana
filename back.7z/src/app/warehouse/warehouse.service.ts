// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import {
  DeepPartial,
  FindManyOptions,
  FindOptionsWhere,
  ILike,
  Raw,
} from 'typeorm';

// Import repositories
import { WarehouseRepository } from './repositories/warehouse.repository';

// Import entity
import { Warehouse } from './entities/warehouse.entity';

// Import entities
import { Cities } from '../cities/entities/cities.entity';

// Import dto
import { CreateWarehouseDto } from './dto/create-warehouse.dto';
import { SelectWarehouseDto } from './dto/select-warehouse.dto';
import { UpdateWarehouseDto } from './dto/update-warehouse.dto';

// Imports
import PermissionUtility from 'src/utils/permission.utility';
import { Exception } from '../../utils/exception.utility';
import { exceptions } from './constants';
import { User } from '../users/entities/user.entity';

@Injectable()
export class WarehouseService {
  // Inject services
  constructor(private readonly warehouseRepository: WarehouseRepository) {}

  /**
   * Create
   * @description Create a new record
   * @param  {CreateWarehouseDto} createWarehouseDto
   */
  async create(createWarehouseDto: CreateWarehouseDto) {
    // Prepare data
    const data: DeepPartial<Warehouse> = {
      code: createWarehouseDto.code.trim(),
      name: createWarehouseDto.name.trim(),
      address: createWarehouseDto.address?.trim(),
      phone: createWarehouseDto.phone?.trim(),
    };

    // If cityId is provided, set the relation
    if (createWarehouseDto.cityId) {
      data.city = { id: createWarehouseDto.cityId } as Cities;
    }

    // Save record
    const result = await this.warehouseRepository.save(data)
      .catch((error) => {
        // Catch error in database transaction duplicated
        if (error.code === '23505')
          throw Exception(
            error.detail.includes('code')
              ? exceptions.duplicated
              : exceptions.duplicatedCode
          );

        // Catch error in database transaction
        throw Exception(exceptions.error_save, [], error);
      });

    // Return result
    return result;
  }

  /**
   * FindAll
   * @description Get all records
   * @param  {SelectWarehouseDto} query
   * @param  {User} user
   */
  async findAll(
    {
      code,
      name,
      cityId,
      active,
      search,
      created_at,
      limit = 20,
      page = 0,
    }: SelectWarehouseDto,
    user: User
  ) {
    const permission = PermissionUtility(user);

    if (permission.user.id.length === 0) return [];

    const andConditions: FindOptionsWhere<Warehouse> = {};
    const orConditions: FindOptionsWhere<Warehouse>[] = [];

    // If search exists
    if (search) {
      orConditions.push(
        { code: ILike(`%${search}%`) },
        { name: ILike(`%${search}%`) }
      );
    }

    if (code) andConditions.code = code;
    if (name) andConditions.name = ILike(`%${name}%`);
    if (cityId) andConditions.city = { id: cityId } as any;
    if (active !== undefined) andConditions.active = active;

    if (created_at) {
      const [year, month] = created_at.split('T')[0].split('-');
      let day = created_at.split('T')[0].split('-')[2];
      const [hour] = created_at.split('T')[1].replace('Z', '').split(':');

      if (parseInt(hour, 10) + 5 >= 24) {
        day = String(parseInt(day, 10) + 1).padStart(2, '0');
      }

      const adjustedStart = `${year}-${month}-${day} 00:00:00`;
      const adjustedEnd = `${year}-${month}-${day} 23:59:59`;

      andConditions.created_at = Raw(
        (alias) =>
          `DATE(${alias} - INTERVAL '5 hours') BETWEEN '${adjustedStart}'::TIMESTAMP 
            AND '${adjustedEnd}'::TIMESTAMP`
      );
    }

    const where =
      orConditions.length > 0
        ? { ...andConditions, OR: orConditions }
        : andConditions;

    // Initialize search
    const init_search: FindManyOptions<Warehouse> = {
      where,
      relations: ['city'],
      skip: limit * page,
      take: limit,
      order: { created_at: 'DESC' },
    };

    // Clear the where if it is empty
    if (
      !init_search.where ||
      (Array.isArray(init_search.where) && init_search.where.length === 0)
    )
      delete init_search.where;

    // Save record
    const result = await this.warehouseRepository
      .find(init_search)
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    const length = await this.warehouseRepository.count({ where });

    // Return result
    return { items: result, length };
  }

  /**
   * FindOne
   * @description Get one record
   * @param  {string} id
   */
  async findOne(id: string, isRequired = true) {
    // Find record
    const result = await this.warehouseRepository
      .findOne({
        where: { id: id },
        relations: ['city'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result && isRequired) throw Exception(exceptions.not_found, []);

    // Return result
    return result;
  }

  /**
   * FindOneByCode
   * @description Get one record by code
   * @param  {string} code
   */
  async findOneByCode(code: string, isRequired = true) {
    // Find record
    const result = await this.warehouseRepository
      .findOne({
        where: { code: code },
        relations: ['city'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result && isRequired) throw Exception(exceptions.not_found, []);

    // Return result
    return result;
  }

  /**
   * FindOneBy
   * @description Get one or multiple records with pagination support
   * @param  {FindOptionsWhere<Warehouse>} where
   * @param  {number} limit
   * @param  {number} page
   */
  async findOneBy(
    where: FindOptionsWhere<Warehouse>,
    limit?: number,
    page?: number
  ) {
    // If limit and page are provided, return paginated results
    if (limit !== undefined && page !== undefined) {
      // Initialize search
      const init_search: FindManyOptions<Warehouse> = {
        where,
        relations: ['city'],
        skip: limit * page,
        take: limit,
        order: { created_at: 'DESC' },
      };

      // Clear the where if it is empty
      if (
        !init_search.where ||
        (Array.isArray(init_search.where) && init_search.where.length === 0)
      )
        delete init_search.where;

      // Find records
      const result = await this.warehouseRepository
        .find(init_search)
        .catch((error) => {
          // Catch error in database transaction
          throw Exception(exceptions.error_find, [], error);
        });

      const length = await this.warehouseRepository.count({ where });

      // Return result with pagination structure
      return { items: result, length };
    }

    // Otherwise, return single record (original behavior)
    const result = await this.warehouseRepository
      .findOne({
        where,
        relations: ['city'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!result) throw Exception(exceptions.not_found, []);

    // Return result
    return result;
  }

  /**
   * FindByUser
   * @description Get all warehouses by user id
   * @param  {string} userId
   */
  async findByUser(userId: string) {
    // Find records using query builder for ManyToMany relation
    const queryBuilder = this.warehouseRepository
      .createQueryBuilder('warehouse')
      .leftJoinAndSelect('warehouse.city', 'city')
      .leftJoinAndSelect('warehouse.users', 'users')
      .innerJoin('warehouse.users', 'user', 'user.id = :userId', { userId })
      .where('warehouse.active = :active', { active: true })
      .orderBy('warehouse.created_at', 'DESC');

    // Get all records
    const result = await queryBuilder.getMany().catch((error) => {
      // Catch error in database transaction
      throw Exception(exceptions.error_find, [], error);
    });

    // Get total count
    const length = await queryBuilder.getCount().catch((error) => {
      // Catch error in database transaction
      throw Exception(exceptions.error_find, [], error);
    });

    // Return result with same structure as findAll
    return { items: result, length };
  }

  /**
   * Update
   * @description Update one record
   * @param  {string} id
   * @param  {UpdateWarehouseDto} updateWarehouseDto
   */
  async update(id: string, updateWarehouseDto: UpdateWarehouseDto) {
    // Save record
    const find = await this.warehouseRepository
      .findOneBy({ id: id })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!find) throw Exception(exceptions.not_found, []);

    // Build update data without copying the entire object
    const data: DeepPartial<Warehouse> = {
      id: find.id,
    };

    if (updateWarehouseDto.code) data.code = updateWarehouseDto.code.trim();
    if (updateWarehouseDto.name) data.name = updateWarehouseDto.name.trim();
    if (updateWarehouseDto.address !== undefined)
      data.address = updateWarehouseDto.address?.trim();
    if (updateWarehouseDto.city !== undefined) {
      data.city = { id: updateWarehouseDto.city } as Cities;
    }
    if (updateWarehouseDto.phone !== undefined)
      data.phone = updateWarehouseDto.phone?.trim();

    // Save record
    const result = await this.warehouseRepository.save(data).catch((error) => {
      // Catch error in database transaction duplicated
      if (error.code === '23505')
        throw Exception(
          error.detail.includes('code')
            ? exceptions.duplicated
            : exceptions.duplicatedCode
        );

      // Catch error in database transaction
      throw Exception(exceptions.error_update, [], error);
    });

    // Reload the record with relations to ensure city is updated
    const updated = await this.warehouseRepository
      .findOne({
        where: { id: result.id },
        relations: ['city'],
      })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // Return result with updated relations
    return updated || result;
  }

  /**
   * Remove
   * @description Remove one record
   * @param  {string} id
   */
  async remove(id: string) {
    // Save record
    const find = await this.warehouseRepository
      .findOneBy({ id: id })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!find) throw Exception(exceptions.not_found, []);

    // Save record
    const result = await this.warehouseRepository
      .save({ ...find, active: false })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_delete, [], error);
      });

    // Return result
    return result;
  }

  /**
   * Reactivate
   * @description Reactivate one record
   * @param  {string} id
   */
  async reactivate(id: string) {
    // Save record
    const find = await this.warehouseRepository
      .findOneBy({ id: id })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_find, [], error);
      });

    // If not found
    if (!find) throw Exception(exceptions.not_found, []);

    // Save record
    const result = await this.warehouseRepository
      .save({ ...find, active: true })
      .catch((error) => {
        // Catch error in database transaction
        throw Exception(exceptions.error_delete, [], error);
      });

    // Return result
    return result;
  }
}

