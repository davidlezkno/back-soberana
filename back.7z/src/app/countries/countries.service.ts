// Import core
import { Injectable } from '@nestjs/common';

// Import typeorm
import { FindManyOptions } from 'typeorm';

// Import repositories
import { CountriesRepository } from './repositories/countries.repository';

// Import entity
import { Countries } from './entities/countries.entity';

@Injectable()
export class CountriesService {
  // Inject services
  constructor(private readonly countriesRepository: CountriesRepository) {}

  /**
   * GetAll
   * @description Get all active records
   */
  async getAll() {
    // Initialize search
    const init_search: FindManyOptions<Countries> = {
      where: {
        isActive: true,
      },
      order: { name: 'ASC' },
    };

    // Get all records
    const result = await this.countriesRepository.find(init_search);

    // Return result
    return result;
  }
}

