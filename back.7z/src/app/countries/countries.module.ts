// Import core
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Import entities
import { Countries } from './entities/countries.entity';

// Import services
import { CountriesService } from './countries.service';

// Import controllers
import { CountriesController } from './countries.controller';

// Import repositories
import { CountriesRepository } from './repositories/countries.repository';

@Module({
  imports: [TypeOrmModule.forFeature([Countries])],
  controllers: [CountriesController],
  providers: [CountriesService, CountriesRepository],
  exports: [CountriesService, CountriesRepository],
})
export class CountriesModule {}

